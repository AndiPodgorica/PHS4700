function acc = Acceleration(F, m)
    % Force / masse
    acc = F / m;
end