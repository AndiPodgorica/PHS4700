function acc = Acceleration(F,m)
    acc = F/m;
end