function omega = AngleRotation(vect)
    omega = atan2(vect(2),(vect(1)));
end