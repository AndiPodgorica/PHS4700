function force_g = ForceGravitationnelle(m)
    g = [0 0 -9.8];
    force_g = m * g;
end