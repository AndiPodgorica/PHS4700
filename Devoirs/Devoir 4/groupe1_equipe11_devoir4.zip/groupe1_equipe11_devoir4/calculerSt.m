function st=calculerSt(Ni,Nt,Si)
st=Si*(Ni/Nt);
end
