function doitRebondir=doitRebondir(rayon)
if rayon.nbrBond<=4
    doitRebondir=true;
else
    doitRebondir=false;
end
end