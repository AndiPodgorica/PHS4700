function [couleur,distance,contactSolide,interieurSphere,point,n]=initialiserRebondValeurs(couleurL)
contactSolide=false;
interieurSphere=false;
couleur=couleurL;
distance=inf;
point=[0;0;0];
n=[0;0;0];
end
