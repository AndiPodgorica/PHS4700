function estPlusPetit=estPlusPetitQueDistance(intersection,distance)
if intersection&&distance>0&&distance<inf
    estPlusPetit=true;
else
    estPlusPetit=false;
end
