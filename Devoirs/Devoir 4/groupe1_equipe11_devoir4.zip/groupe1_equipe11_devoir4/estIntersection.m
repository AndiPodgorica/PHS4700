function estIntersection=estIntersection(distance,intersection,distanceP)
if distance>0&&intersection==true&&distance<distanceP
    estIntersection=true;
else
    estIntersection=false;
end
