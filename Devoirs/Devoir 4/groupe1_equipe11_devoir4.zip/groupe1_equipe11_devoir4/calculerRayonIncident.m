function incident=calculerRayonIncident(point,rayon)
incident={};
incident.posDepart=rayon.posDepart;
incident.ligneU=rayon.ligneU;
incident.nbrBond=rayon.nbrBond;
incident.lignePos=point;
incident.c=rayon.c;
incident.d=rayon.d;
incident.posU=rayon.posU;
end