function rebondir=estPlusPetitDistance(dPetitApres)
if inf==dPetitApres
    rebondir=false;
else
    rebondir=true;
end