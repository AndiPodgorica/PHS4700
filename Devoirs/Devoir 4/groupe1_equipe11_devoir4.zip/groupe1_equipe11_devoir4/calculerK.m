function k=calculerK(n,j)
k=cross(n/norm(n),j);
k=k/norm(k);
end
