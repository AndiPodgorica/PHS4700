function plan=creerPlan(c,n,d,l,h)
plan={};
plan.c=c;
plan.n=n;
plan.d=d;
plan.l=l;
plan.h=h;
end