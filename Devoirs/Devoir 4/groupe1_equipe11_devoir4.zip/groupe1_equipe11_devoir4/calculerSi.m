function si=calculerSi(k,direction)
si=dot(k,direction/norm(direction));
end