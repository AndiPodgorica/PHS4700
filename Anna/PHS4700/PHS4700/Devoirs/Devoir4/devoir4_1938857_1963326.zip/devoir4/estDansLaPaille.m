function [out, couleur] = estDansLaPaille(ligne, posPailleXYP, rayonPaille, hauteurPaille);
  estDansXY = (ligne(1) - posPailleXYP(1))^2 + (ligne(2) - posPailleXYP(2))^2 <= rayonPaille^2;
  estDansHauteur = 0 <= ligne(3) && ligne(3) <= hauteurPaille;
  
  if (estDansXY && estDansHauteur)
    out = true;
    sectionCouleur = (hauteurPaille - 0) / 5;
    couleur = fix(ligne(3) / sectionCouleur) + 1;
  else
    out = false;
    couleur = 0;
  endif
end;
  