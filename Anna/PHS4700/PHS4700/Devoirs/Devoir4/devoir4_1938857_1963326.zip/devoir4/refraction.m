function [outVecteurUnitaireMouvement, outARefracte] = refraction(vuAttaque, vuPlan, n1attaquant);
  # vu veut dire vecteur unitaire
  
  # indices de r�fraction
    n_air = 1;
    n_eau = 1.333;
  
  n2sortant = n_air;
  
  if (n1attaquant == n_air)
    n2sortant = n_eau;
  endif
  
  ui = vuAttaque;
  
  i  = vuPlan / norm(vuPlan);
  j  = cross(ui, i) / norm(cross(ui, i));
  k  = cross(i, j);
  
  angleAttaque  = asin(dot(ui, k));
  angleSortant  = n1attaquant/n2sortant * dot(ui, k);
  angleCritique = abs(asin(n2sortant/n1attaquant));
  
  if (-angleCritique <= angleCritique && angleCritique <= angleCritique)
    ut = -i * sqrt(1 - angleSortant^2) + k * angleSortant;
    outVecteurUnitaireMouvement = ut / norm(ut);
    outARefracte = true;
  else
    outVecteurUnitaireMouvement = [0; 0; 0];
    outARefracte = false;
  endif
end;
