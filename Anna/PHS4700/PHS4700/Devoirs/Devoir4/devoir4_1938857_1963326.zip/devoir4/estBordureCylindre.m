function [out] = estBordureCylindre(ligne, he, rayonCylindre);
  estDansMaxXY = (ligne(1) - 0)^2 + (ligne(2) - 0)^2 <= rayonCylindre;
  estDansMinXY = rayonCylindre * 0.97 <= (ligne(1) - 0)^2 + (ligne(2) - 0)^2;
  
  estDansHautMaxZ = ligne(3) <= he;
  estDansHautMinZ = he * 0.98 <= ligne(3);
  
  estDansBasMaxZ = ligne(3) <= he * 0.02;
  estDansBasMinZ = 0 <= ligne(3);
  
  # est-ce qu'il y a une r�fraction ou un r�flexion totale interne
  if (estDansMaxXY && estDansMinXY && estDansHautMaxZ && estDansBasMinZ) # c�t�
    out = true;
  elseif (estDansMaxXY && estDansHautMaxZ && estDansHautMinZ) # le haut
    out = true;
  elseif (estDansMaxXY && estDansBasMaxZ && estDansBasMinZ) # le bas
    out = true;
  else
    out = false;
  endif;
end;
