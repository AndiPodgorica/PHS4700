function [xi yi zi couleur] = Devoir4(Robs, xyp, he);
  
  # constantes
  
    # paille multicolore cylindrique multicolore
    r_p = 5 / 1000; # rayon de 5 mm en m�tre
    h_p = 25 / 100; # hauteur de 25 cm en m�tre
    
    # verre en plastique cylindrique
    r_v = 4 / 100; # rayon de 4 cm en m�tre
    h_v = 20 / 100; # hauteur de 20 cm en m�tre
    
    # indices de r�fraction
    n_air = 1;
    n_eau = 1.333;
  
  # 6000 points lanc�s des yeux de Robs
    nb_point_largeur = 125;
    nb_point_hauteur = 48;
  
  # distance entre Robs et centre du cylindre en plastique
    d_Robs_projection = sqrt(Robs(1)^2 + Robs(2)^2);
  
  # largeur maximale/minimale et son d�cr�ment
    maxLargeur =   r_v; % d�j� ramen� � l'origine
    minLargeur = - r_v;
    itLargeur  = - r_v*2 / nb_point_largeur;
  
  # hauteur minimale/maximale et son d�cr�ment
  # on suppose la hauteur � partir de Robs qui regarde le cylindre
    maxHauteur = h_p; # la hauteur maximale qui peut regarder est la hauteur de la paille
  
    minHauteur = 0; # la hauteur minimale est l'origine
    itHauteur  = - (maxHauteur - minHauteur) / nb_point_hauteur;
  
  # pr�paration des vecteurs pour les r�ponses
    xi = [];
    yi = [];
    zi = [];
    couleur = [];
  
  # 1 mm parcourue par it�ration
  d_it = 0.001;
  
  # pour savoir quelle position qu'il faut remplir, car on ne peut pas mettre z�ro
  indexPresent = 0;
  
  for hauteur = 0:(nb_point_hauteur - 1)
    disp(["La hauteur ", num2str(hauteur + 1), " est en train de dessiner sur ", num2str(nb_point_hauteur)]);
    for largeur = 0:(nb_point_largeur - 1)
        
      # d�but d'une nouvelle ligne de l'observateur et un vecteur unitaire de mouvement
      nbReflection = 0;
      
      # position initiale de la ligne est l'observateur
      ligne = Robs;
      
      # g�n�ration du premier vecteur de mouvement unitaire
      if (Robs(1) == 0)
        vecteurMouvementX = maxLargeur + itLargeur * largeur;
        vecteurMouvementY = 0 - d_Robs_projection;
      else
        vecteurMouvementX = 0 - d_Robs_projection;
        vecteurMouvementY = maxLargeur + itLargeur * largeur;
      endif
      vecteurMouvementZ   = (maxHauteur + itHauteur * hauteur) - Robs(3);
      vecteurUnitaireMouvement = [vecteurMouvementX; vecteurMouvementY; vecteurMouvementZ] / sqrt(vecteurMouvementX^2 + vecteurMouvementY^2 + vecteurMouvementZ^2);
      
      # n_air ou n_eau en commen�ant
      ligneEstDans = n_air;
      
      # pour aider � savoir si une couleur est d�j� l� dans la pr�sente it�ration
      couleurPresente = 0;
      
      # pour savoir si �a a frapp� quelque chose pour que indexPresent monte
      aFrappeQuelqueChose = false;
      
      while (nbReflection < 10)
        # bouger la ligne selon le vecteur unitaire de mouvement
        ligne += d_it * vecteurUnitaireMouvement;
        
        # v�rifier si ce n'est pas trop en-dehors
        # mesure de protection
        XestDehors = abs(ligne(1)) > 0.1;
        YestDehors = abs(ligne(2)) > 0.1;
        ZestDehors = ligne(3) < -0.1 && 0.3 < ligne(3);
        
        if (XestDehors || YestDehors || ZestDehors) # donc hors de tout compl�tement
          nbReflection = 100;
        else
          # la ligne frappe la couleur de la paille 
          [outEstDansLaPaille, outCouleur] = estDansLaPaille(ligne, xyp, r_p, h_p);
          if (outEstDansLaPaille && couleurPresente == 0)
            
            if (!aFrappeQuelqueChose)
              indexPresent += 1;
            endif;
            
            couleur(indexPresent) = outCouleur;
            xi(indexPresent) = ligne(1);
            yi(indexPresent) = ligne(2);
            zi(indexPresent) = ligne(3);
            
            couleurPresente = outCouleur;
          endif;
          # ajout de la r�fraction et de la r�flexion totale interne
          [outEstDansBordureCylindre] = estBordureCylindre(ligne, he, r_v);
          
          if (outEstDansBordureCylindre)
            
            if (!aFrappeQuelqueChose)
              indexPresent += 1;
            endif;
            
            aRefracte = false;
            
            [outVecteurUnitaireMouvement, outARefracte] = refraction(vecteurUnitaireMouvement, ligne, ligneEstDans);
            aRefracte = outARefracte;
            
            if (!aRefracte) # r�flexion totale interne si r�fraction ne fonctionne pas
              [outVecteurUnitaireMouvement] = reflexionTotaleInterne(vecteurUnitaireMouvement, ligne);
            endif;
            
            vecteurUnitaireMouvement = outVecteurUnitaireMouvement;
            
            # alternance de milieu s'il y a eu r�fraction
            if (aRefracte)
              if (ligneEstDans == n_air)
                ligneEstDans = n_eau;
              else
                ligneEstDans = n_air;
              endif
            endif
            
            nbReflection += 1;
          endif
          
        endif
      endwhile
      
      if (nbReflection == 10)
        xi(end + 1) = ligne(1);
        yi(end + 1) = ligne(2);
        zi(end + 1) = ligne(3);
      endif

    endfor
  endfor
  
  disp(["Il y a ", num2str(length(couleur)), " points g�n�r�s."]);
  
end
