function [outVecteurUnitaireMouvement] = reflexionTotaleInterne(vuAttaque, vuPlan);
  ur = vuAttaque - 2 * vuPlan * dot(vuAttaque, vuPlan);
  outVecteurUnitaireMouvement = ur / norm(ur);
end;
